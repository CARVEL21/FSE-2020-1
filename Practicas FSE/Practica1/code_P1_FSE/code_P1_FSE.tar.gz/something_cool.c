#include <stdio.h>

int main(int argc, char **argv) {
	int i = 0;
	printf("Hello world!\n");

	for (i=1;i<=15; i++){
	printf("# %d FSE2020-1 CVCA HRP \n", i );
	}
	return 0;
}
